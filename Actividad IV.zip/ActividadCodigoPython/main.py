

# Importar librerias python 
from fastapi import FastAPI, Body #Framework utilizado para la construcción de aplicaciones de lado del servidor
from fastapi.responses import HTMLResponse #Retorna la respuesta enviada de HTML desde FastAPI a traves del HTMLRespose
from pydantic import BaseModel, Field #Permite la validación de datos y gestión de configuraciones mediante anotaciones
from typing import Optional #permitir anotar los tipos de forma nativa 

app = FastAPI()#Creación Framework para la aplicación y gestión de datos del servidor (restServer)

app.title = "Aplicación para la gestión de venta de ropa."#Titulo de la aplicación

app.version = "0.0.1" #Version de la aplicación

#Creación de la clase Ropas y de la plantilla de la base de datos
class Ropas (BaseModel):
#Atributos utilizados en la base de datos para cada uno de los objetos
    id : Optional[int]
    marca: str
    categoria: str
    color: str
    talla: str
    precio: float
#Declaración de las variables empleadas en la base de datos
    class Config():
        schema_extra = {
            "defaults" : {
                "id" : 1,
                "marca" : "No name",
                "color" : "No name",
                "categoria" : "No categoria",
                "talla" : "No talla",
                "precio" : "No categoria"
            }
        }
#Especifica a FastAPI que la función que hay debajo es la encargada de gestionar las peticiones. 
@app.get("/", tags=['Inicio'])
def message():
    #Retorna una respuesta en Html
    return HTMLResponse('<h1> Hola bienvenidos al  Modelo Servidor-cliente venta de ropa </h1>')
#Creación de la Base de datos de la aplicación
inventario = [
    {
    #Objeto 1 
        'id': 1,
        'marca': 'Arturo Calle',
        'categoria': "Camisas",
        'color': "Blanco",
        'talla': 'L',
        'precio': 50.0,  
    },
    {
    #Objeto 2
        'id': 2,
        'marca': 'H&M',
        'categoria': "Pantalones - Jean",
        'color': "Azul",
        'talla': '38',
        'precio': 90.0,  
    },
    {
    #Objeto 3
        'id': 3,
        'marca': 'Nike',
        'categoria': "Calzado - Sport",
        'color': "Rojo - Blanco",
        'talla': '40',
        'precio': 180.0,  
    },
    {
    #Objeto 4
        'id': 4,
        'marca': 'Pat-primo',
        'categoria': "Ropa interior - Masculina",
        'color': "Negro",
        'talla': '32',
        'precio': 45.0,  
    },
]
#Get Especifica a FastAPI que la función que hay debajo es la encargada de gestionar las peticiones.
#Obtener ropa trae toda la información de la base de datos
@app.get("/ropa", tags= ['ropas'])
def obtener_ropa():
#Retorna  en el inventario los productos de la base de datos
    return inventario

# Parametros: 
#obtener ropa con parametro Id, retorna el id del objeto solicitado por el usuario
@app.get("/ropa/{id}", tags= ['ropas'])
def obtener_ropa(id : int):
    result = list(filter(lambda item: item['id'] == id, inventario))
    return result
#Post Permite enviarle una solicitud al servidor para que modifique o use los datos que se le dan
#Crear ropa crea un nuevo producto enviandole los atributos del objeto
@app.post("/ropa", tags= ['ropas'])
def crear_ropa(ropa: Ropas):
    inventario.append({
        "id" : ropa.id,
        "marca" : ropa.marca,
        "categoria" : ropa.categoria, 
        "color" : ropa.color, 
        "talla" : ropa.talla,
        "precio" : ropa.precio,
    })
    return inventario
#Put permite editar un único recurso que ya forma parte de un grupo de recursos y procedimientos de actualización.
#Actualizar ropa el item del producto que desee cambiar el usuario y lo retorna en el inventario base de datos
@app.put("/ropa/{id}", tags= ['ropas'])
def actualizar_ropa(id:int, ropa : Ropas):
    
    for item in inventario: 
        print(item)
        if item['id'] == id:
                print(item)
                item["marca"] = ropa.marca
                item["categoria"] = ropa.categoria 
                item["color"] = ropa.color
                item["talla"] = ropa.talla
                item["precio"] = ropa.precio 
                return inventario
        else:
            return "The Id there is not in DB"
#Elimina cualquier elemento de la lista de objetos
#Borrar ropa elminia a traves del id un producto del inventario en la base de datos      
@app.delete("/ropa/{id}", tags = ['ropas'])
def borrar_ropa(id : int): 
    for item in inventario:
        if item['id'] == id:
            inventario.remove(item)
    return inventario