
Hola Profesor, siguiendo estos pasos puedes visualizar y probar mi trabajo. 

Usaremos una simple configuración para windows:

REQUERIDO: 

1. Tener instalado Python en el pc 
2. Tener instalado Pip en el pc 
3. Tener instalado Visual Studio Code

Abrir la carpeta en en VSCO y utilizar abrir una linea de comandos para la ejecución 
de lo siguientes comandos:  

--> crear entorno virtual (Evitar choque de dependencias)

python -m venv env 

--> activar entorno virtual

env\Scripts\activate 

--> instalar las dependencias que yo uso en mi proyecto

pip install -r requirements.txt

--> correr proyecto (server)

uvicorn main:app --reload --port 5000

--> El server te va dar una URL en el local HOST. Aqui te tienes que pasar a la ruta /docs

Ejemplo: 

http://127.0.0.1:5000/docs


y listo, puedes ver la interfaz grafica y usar mis métodos